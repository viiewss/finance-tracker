package com.mahirmohtasin.financetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
